package Model;

public class ClientRequest {
    private int id;
    private int clientId;
    private String requestDetails;

    // Constructors, getters, setters
}
